//
//  GameModel.swift
//  CarGame
//
//  Created by Adun Adunov on 18.10.2025.
//

import Foundation

final class GameModel {

    // Состояние
    var score = 0
    var isRunning = true
    static var totalCollisions = 0

    // Бустеры
    private var speedBoostEndTime: Date?
    private var slowModeEndTime: Date?
    private var scoreBoostEndTime: Date?

    var isSpeedBoostActive: Bool { speedBoostEndTime.map { Date() < $0 } ?? false }
    var isSlowModeActive: Bool { slowModeEndTime.map { Date() < $0 } ?? false }
    var isScoreBoostActive: Bool { scoreBoostEndTime.map { Date() < $0 } ?? false }

    var scoreMultiplier: Int { isScoreBoostActive ? 2 : 1 }
    var moveStep: CGFloat { isSpeedBoostActive ? 16.0 : 8.0 }
    var ObstacleViewModelSpeed: CGFloat { isSlowModeActive ? 2.0 : 4.0 }

    // MARK: - Game Logic

    func update() {
        updateBoostTimers()
    }

    private func updateBoostTimers() {
        let now = Date()
        if let end = speedBoostEndTime, now > end { speedBoostEndTime = nil }
        if let end = slowModeEndTime, now > end { slowModeEndTime = nil }
        if let end = scoreBoostEndTime, now > end { scoreBoostEndTime = nil }
    }

    func activateBoosterViewModel(_ type: BoosterType) {
        let endTime = Date().addingTimeInterval(10)
        switch type {
        case .speed: speedBoostEndTime = endTime
        case .slow: slowModeEndTime = endTime
        case .score: scoreBoostEndTime = endTime
        }
    }

    func addScore(_ points: Int) {
        score += points * scoreMultiplier
    }

    func handleCollision() {
        GameModel.totalCollisions += 1
        isRunning = false
    }

    func reset() {
        score = 0
        isRunning = true
        speedBoostEndTime = nil
        slowModeEndTime = nil
        scoreBoostEndTime = nil
    }
}
