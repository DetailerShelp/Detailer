//
//  BoosterViewModel.swift
//  CarGame
//
//  Created by Adun Adunov on 18.10.2025.
//

import UIKit

struct BoosterViewModel {
    var view: UIView
    let type: BoosterType
    static let size = CGSize(width: 30, height: 30)
}

enum BoosterType: Int, CaseIterable {
    case speed = 1
    case slow = 2
    case score = 3

    var color: UIColor {
        switch self {
        case .speed: return .green
        case .slow: return .blue
        case .score: return .yellow
        }
    }
}
