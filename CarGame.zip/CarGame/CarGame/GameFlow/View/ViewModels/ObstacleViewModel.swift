//
//  Obstacke.swift
//  CarGame
//
//  Created by Adun Adunov on 18.10.2025.
//

import UIKit

struct ObstacleViewModel{
    var view: UIView
    static let size = CGSize(width: 50, height: 50)
}

