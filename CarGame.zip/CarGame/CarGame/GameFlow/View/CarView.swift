//
//  CarView.swift
//  CarGame
//
//  Created by Adun Adunov on 18.10.2025.
//

import UIKit

final class CarView: UIView {
    
    // MARK: - UI Properties
    
    let icon: UIImageView
    
    // MARK: - Initialization
    
    init(frame: CGRect, iconImage: UIImage) {
        self.icon = UIImageView(image: iconImage)
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup
    
    func setupView() {
        backgroundColor = .clear

        icon.frame = bounds
        icon.contentMode = .scaleAspectFill
        icon.clipsToBounds = true
        icon.layer.cornerRadius = 6

        addSubview(icon)
    }
    
    // MARK: - Methods

    func visibleFrame(in superview: UIView) -> CGRect {
        let originalFrame = icon.convert(icon.bounds, to: superview)
        let inset: CGFloat = 20 
        let insetRect = originalFrame.insetBy(dx: inset, dy: inset)
        return insetRect
    }

}
