// ViewController.swift

// ViewController.swift

import UIKit

class GameViewController: UIViewController {

    // MARK: - View Properties

    private var carView: CarView!
    private var scoreLabel: UILabel!
    private var obstacleViewModels: [ObstacleViewModel] = []
    private var boosterViewModels: [BoosterViewModel] = []
    private var backgroundViews: [UIImageView] = []
    private var backButton: UIButton!

    // MARK: - Models

    private var gameModel = GameModel()
    private var gameTimer: Timer?

    // MARK: - Inputs

    private var isMovingLeft = false
    private var isMovingRight = false

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .gray
        setupUI()
        startGame()
    }

    // MARK: - Deinit

    deinit {
        gameTimer?.invalidate()
    }
    
    // MARK: - Overrides

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { handleTouch(touches) }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) { handleTouch(touches) }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { stopMoving() }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { stopMoving() }

}

private extension GameViewController {

    func setupUI() {
        // Car
        carView = CarView(
            frame: CGRect(x: 50, y: view.bounds.height - 120, width: 90, height: 90),
            iconImage: UIImage(named: "car_main")!
        )
        view.addSubview(carView)
        setupBackground()

        // Score label
        scoreLabel = UILabel()
        scoreLabel.font = .boldSystemFont(ofSize: 20)
        scoreLabel.textColor = .white
        scoreLabel.textAlignment = .right
        scoreLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scoreLabel)

        // Back button
        backButton = UIButton(type: .system)
        backButton.setTitle("<", for: .normal)
        backButton.setTitleColor(.white, for: .normal)
        backButton.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        backButton.layer.cornerRadius = 8
        backButton.translatesAutoresizingMaskIntoConstraints = false
        backButton.addTarget(self, action: #selector(backToMenu), for: .touchUpInside)
        view.addSubview(backButton)

        // Constraints
        NSLayoutConstraint.activate([
            scoreLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            scoreLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            backButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            backButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            backButton.widthAnchor.constraint(equalToConstant: 30),
            backButton.heightAnchor.constraint(equalToConstant: 30)
        ])

        view.bringSubviewToFront(scoreLabel)
        view.bringSubviewToFront(backButton)
    }
    
    @objc
    func backToMenu() {
        gameTimer?.invalidate()
        dismiss(animated: false)
    }
    func setupBackground() {
        let backgroundImage = UIImage(named: "road")
        guard backgroundImage != nil else {
            print("⚠️ Изображение 'road' не найдено в Assets!")
            view.backgroundColor = UIColor(white: 0.2, alpha: 1.0)
            return
        }

        for i in 0..<2 {
            let bgView = UIImageView(image: backgroundImage)
            bgView.contentMode = .scaleAspectFill
            bgView.frame = CGRect(
                x: 0,
                y: CGFloat(i) * view.bounds.height,
                width: view.bounds.width,
                height: view.bounds.height
            )
            bgView.autoresizingMask = [.flexibleWidth]
            view.insertSubview(bgView, at: 0)
            backgroundViews.append(bgView)
        }
    }
    func moveBackground() {
        let speed = gameModel.ObstacleViewModelSpeed + 10

        for bgView in backgroundViews {
            bgView.frame.origin.y += speed

            if bgView.frame.origin.y >= view.bounds.height {
                let minY = backgroundViews.map { $0.frame.minY }.min() ?? 0
                bgView.frame.origin.y = minY - view.bounds.height
            }
        }
    }
    func startGame() {
        gameModel.reset()
        updateScoreLabel()
        startGameLoop()
    }

    func startGameLoop() {
        gameTimer?.invalidate()
        gameTimer = Timer.scheduledTimer(withTimeInterval: 1/60, repeats: true) { _ in
            self.gameModel.update()
            self.updateGame()
        }
    }

    // MARK: - Game Loop

    func updateGame() {
        guard gameModel.isRunning else { return }

        spawnObstacleViewModelIfNeeded()
        spawnBoosterViewModelIfNeeded()
        moveCar()
        moveObstacleViewModelsAndBoosterViewModels()
        moveBackground()
        checkCollisions()
        updateScoreLabel()
    }

    func spawnObstacleViewModelIfNeeded() {
        guard Int.random(in: 0...100) == 0 else { return }

        let obstacleWidth = ObstacleViewModel.size.width + 35
        let obstacleHeight = ObstacleViewModel.size.height + 35
        let spawnY: CGFloat = -obstacleHeight


        let maxAttempts = 20
        for _ in 0..<maxAttempts {
            let maxX = view.bounds.width - obstacleWidth
            guard maxX > 0 else { return }
            let x = CGFloat.random(in: 0...maxX)
            let candidateRect = CGRect(x: x, y: spawnY, width: obstacleWidth, height: obstacleHeight)

            let isOverlapping = obstacleViewModels.contains { obstacle in
                let obstacleRect = obstacle.view.frame
                let safeRect = obstacleRect.insetBy(dx: -20, dy: 0)
                return candidateRect.intersects(safeRect)
            }

            if !isOverlapping {
                guard let enemyImage = UIImage(named: "car-enemy") else {
                    print("⚠️ Изображение 'car-enemy' не найдено!")
                    return
                }

                let obstacleImageView = UIImageView(image: enemyImage)
                obstacleImageView.frame = candidateRect
                obstacleImageView.contentMode = .scaleAspectFill
                obstacleImageView.clipsToBounds = true
                view.addSubview(obstacleImageView)
                obstacleViewModels.append(ObstacleViewModel(view: obstacleImageView))
                return
            }
        }

    }

    func spawnBoosterViewModelIfNeeded() {
        guard Int.random(in: 0...300) == 0 else { return }
        let type = BoosterType.allCases.randomElement()!
        let maxX = view.bounds.width - BoosterViewModel.size.width
        let x = CGFloat.random(in: 0...maxX)
        let BoosterViewModelView = UIView(frame: CGRect(x: x, y: -BoosterViewModel.size.height, width: BoosterViewModel.size.width, height: BoosterViewModel.size.height))
        BoosterViewModelView.backgroundColor = type.color
        BoosterViewModelView.layer.cornerRadius = BoosterViewModel.size.width / 2
        BoosterViewModelView.tag = type.rawValue
        view.addSubview(BoosterViewModelView)
        boosterViewModels.append(BoosterViewModel(view: BoosterViewModelView, type: type))
    }

    func moveCar() {
        let frame = carView.frame
        var x = frame.origin.x
        if isMovingLeft { x -= gameModel.moveStep }
        if isMovingRight { x += gameModel.moveStep }
        x = max(0, min(x, view.bounds.width - frame.width))
        carView.frame.origin.x = x
    }

    func moveObstacleViewModelsAndBoosterViewModels() {
        obstacleViewModels = obstacleViewModels.compactMap { obstacle in
            obstacle.view.frame.origin.y += gameModel.ObstacleViewModelSpeed
            if obstacle.view.frame.origin.y > view.bounds.height {
                gameModel.addScore(1)
                obstacle.view.removeFromSuperview()
                return nil
            }
            return obstacle
        }

        boosterViewModels = boosterViewModels.compactMap { booster in
            booster.view.frame.origin.y += gameModel.ObstacleViewModelSpeed * 0.8
            if booster.view.frame.origin.y > view.bounds.height {
                booster.view.removeFromSuperview()
                return nil
            }
            return booster
        }
    }

    func removeObstacleViewModels(_ list: [ObstacleViewModel]) {
        for obs in list {
            obs.view.removeFromSuperview()
        }
        obstacleViewModels.removeAll { removedObstacle in
            list.contains { $0.view == removedObstacle.view }
        }
    }

    func removeBoosterViewModels(_ list: [BoosterViewModel]) {
        for b in list {
            b.view.removeFromSuperview()
        }
        boosterViewModels.removeAll() { removedBooster in
            list.contains { $0.view == removedBooster.view }
        }
    }

    func checkCollisions() {
        let carFrame = carView.visibleFrame(in: view)

        for obstacle in obstacleViewModels {
            let obstacleFrame = obstacle.view.frame
            let collisionRect = obstacleFrame.insetBy(dx: obstacleFrame.width * 0.5, dy: obstacleFrame.height * 0.15)
            if carFrame.intersects(collisionRect) {
                gameModel.handleCollision()
                resetGameAfterDelay()
                return
            }
        }

        // Бустеры
        var BoosterViewModelsToRemove: [BoosterViewModel] = []
        for boosterViewModels in boosterViewModels {
            if carFrame.intersects(boosterViewModels.view.frame) {
                gameModel.activateBoosterViewModel(boosterViewModels.type)
                BoosterViewModelsToRemove.append(boosterViewModels)
            }
        }
        removeBoosterViewModels(BoosterViewModelsToRemove)
    }

    func updateScoreLabel() {
        scoreLabel.text = "Score: \(gameModel.score)"
    }

    func resetGameAfterDelay() {
        gameTimer?.invalidate()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.obstacleViewModels.forEach { $0.view.removeFromSuperview() }
            self.boosterViewModels.forEach { $0.view.removeFromSuperview() }
            self.obstacleViewModels.removeAll()
            self.boosterViewModels.removeAll()

            self.dismiss(animated: false)
        }
    }

}

// MARK: - Handle Tapping

private extension GameViewController {

    func handleTouch(_ touches: Set<UITouch>) {
        guard let touch = touches.first else { return }
        let x = touch.location(in: view).x
        let half = view.bounds.width / 2
        isMovingLeft = x < half
        isMovingRight = x >= half
    }

    func stopMoving() {
        isMovingLeft = false
        isMovingRight = false
    }

}
