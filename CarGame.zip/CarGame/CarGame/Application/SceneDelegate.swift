//
//  SceneDelegate.swift
//  CarGame
//
//  Created by Adun Adunov on 18.10.2025.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }

        window = UIWindow(windowScene: windowScene)
        
        let menuVC = MenuViewController()
        window?.rootViewController = menuVC
        window?.makeKeyAndVisible()
    }
}

