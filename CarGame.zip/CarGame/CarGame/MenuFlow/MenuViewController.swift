//
//  MenuViewController.swift
//  CarGame
//
//  Created by Adun Adunov on 25.10.2025.
//

import UIKit

class MenuViewController: UIViewController {

    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "🏎️ Car Game"
        label.font = .boldSystemFont(ofSize: 40)
        label.textColor = .white
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Game", for: .normal)
        button.titleLabel?.font = .boldSystemFont(ofSize: 24)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 12
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    // MARK: - Booster Info Labels

    private let boosterInfoStack: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 12
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.black
        setupUI()
        setupBoosterInfo()
    }

    private func setupUI() {
        view.addSubview(titleLabel)
        view.addSubview(startButton)
        view.addSubview(boosterInfoStack)

        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            startButton.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 60),
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            startButton.widthAnchor.constraint(equalToConstant: 200),
            startButton.heightAnchor.constraint(equalToConstant: 50),

            boosterInfoStack.topAnchor.constraint(equalTo: startButton.bottomAnchor, constant: 40),
            boosterInfoStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            boosterInfoStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40)
        ])

        startButton.addTarget(self, action: #selector(startGameTapped), for: .touchUpInside)
    }

    private func setupBoosterInfo() {
        let speedLabel = createBoosterLabel(color: BoosterType.speed.color, text: "— Speed Boost")
        let slowLabel = createBoosterLabel(color: BoosterType.slow.color, text: "— Slow Motion")
        let scoreLabel = createBoosterLabel(color: BoosterType.score.color, text: "— 2x Score")

        boosterInfoStack.addArrangedSubview(speedLabel)
        boosterInfoStack.addArrangedSubview(slowLabel)
        boosterInfoStack.addArrangedSubview(scoreLabel)
    }

    private func createBoosterLabel(color: UIColor, text: String) -> UIView {
        let rowStack = UIStackView()
        rowStack.axis = .horizontal
        rowStack.spacing = 10
        rowStack.alignment = .center

        let colorView = UIView()
        colorView.backgroundColor = color
        colorView.layer.cornerRadius = 10
        colorView.widthAnchor.constraint(equalToConstant: 20).isActive = true
        colorView.heightAnchor.constraint(equalToConstant: 20).isActive = true

        let label = UILabel()
        label.text = text
        label.textColor = .lightGray
        label.font = .systemFont(ofSize: 16)

        rowStack.addArrangedSubview(colorView)
        rowStack.addArrangedSubview(label)

        return rowStack
    }

    @objc private func startGameTapped() {
        let gameVC = GameViewController()
        gameVC.modalPresentationStyle = .fullScreen
        present(gameVC, animated: true)
    }
}
